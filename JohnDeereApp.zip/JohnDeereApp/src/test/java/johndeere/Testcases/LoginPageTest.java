package johndeere.Testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import johndeere.base.TestBase;
import johndeere.pages.HomePage;
import johndeere.pages.LoginPage;

public class LoginPageTest extends TestBase {

	LoginPage loginPage;
	HomePage homePage;

	public LoginPageTest() {
		super();
	}

	@BeforeTest
	public void precondition() throws InterruptedException {
		initialization();
		loginPage = new LoginPage();
		Thread.sleep(2000);

	}
	
	
	@Test(priority = 0)
	public void TestForToGetData_FromExcel() throws IOException {

		System.out.println(loginPage.getData("Kartik"));
		System.out.println(loginPage.getData("Kelkar"));
		System.out.println(loginPage.getData("Lucky"));
	}


//	@Test(priority = 1)
//	public void loginPageTitleTest() {
//
//		logger = extent.createTest("Verify login page title");
//		String title = loginPage.validateLoginPageTitle();
//		try {
//			Assert.assertEquals(title, "John Deere (johndeerecert.) - Sign In"); 
//			logger.createNode("Login page title is verified").pass("Login page title is- " + title);
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//	}
//
//	@Test(priority = 2)
//	public void VerifyLogin_WithIncorrectCreds() throws InterruptedException {
//		logger = extent.createTest("Verify login error with incorrect credentials");
//		loginPage.login(prop.getProperty("WrongUserName"), prop.getProperty("WrongPassword"));
//
//		boolean flag = loginPage.LoginErrorCheck();
//		if (flag == true) {
//			logger.createNode("Error message is displayed for invalid creds")
//					.pass("Error message is displayed for invalid creds");
//
//		} else {
//			logger.createNode("Error message is not displayed for invalid creds")
//					.fail("Error message is not displayed for invalid creds");
//		}
//	}

//	//Note-As correct creds are not provided by team, once we have correct creds we can uncomment it.
//	@Test(priority = 3)
//	public void VerifyLogin_WithCorrectCreds() throws InterruptedException {
//		logger = extent.createTest("Verify login with correct credentials"); 
//		loginPage.login(prop.getProperty("UserName"), prop.getProperty("Password"));
//	
//		boolean flag=loginPage.LoginErrorCheck();
//		 if(flag==true) {
//			    logger.createNode("Error message is displayed for valid creds").fail("Error message is displayed for valid creds");
//			}else {
//				logger.createNode("Error message is not displayed for valid creds").pass("Error message is not displayed for valid creds");
//			}	
//	}
	
	
	
	

//	@AfterMethod
//	public void teardown1(ITestResult result) throws IOException {
//		if (result.getStatus() == ITestResult.SUCCESS) {
//			logger.log(Status.PASS, "Test Case passed is " + result.getName());
//			String screenshotPath = getScreenshot(driver, result.getName());
//			logger.addScreenCaptureFromPath(screenshotPath);
//		} else if (result.getStatus() == ITestResult.FAILURE) {
//			logger.log(Status.FAIL, "Test Case Failed is " + result.getName() );
//			logger.log(Status.FAIL, result.getThrowable());
//			String screenshotPath = getScreenshot(driver, result.getName());
//			logger.addScreenCaptureFromPath(screenshotPath);
//		}
//	}

	@AfterSuite
	public void teardown() {
		driver.quit();
	}

}

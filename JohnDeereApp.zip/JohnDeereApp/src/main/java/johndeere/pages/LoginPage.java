package johndeere.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import johndeere.base.TestBase;

public class LoginPage extends TestBase {
	LoginPage loginpage;
	
	public void LogingPage() {
		PageFactory.initElements(driver, this);
	}
	
	public String getData(String inputData) throws IOException {
		
		
		String  data=getDataFromExl("Sheet1", inputData);
		   
		
		return data;
	}
	

	// Web Element locator path

	@FindBy(xpath = "//input[@name='username']")
	WebElement userNameBar_loginPage;

	@FindBy(xpath = "//input[@name='password']")
	WebElement pwdNameBar_loginPage;

	@FindBy(xpath = "//input[@class='button button-primary']")
	WebElement loginButton_loginPage;

	@FindBy(xpath = "//span[@class='icon error-16']")
	WebElement wrongCredError_loginPage;

	
	

	public String validateLoginPageTitle() {
		String title = driver.getTitle();
		return title;
	}

	public Boolean validateLogo() {
		WebElement logo = driver.findElement(By.xpath("//img[@class='auth-org-logo']"));
		return logo.isDisplayed();
	}

	public void login(String id, String pwd) {
//		WebElement userName = driver.findElement(By.xpath("//input[@name='username']"));
//		WebElement password = driver.findElement(By.xpath("//input[@name='password']"));
//		WebElement loginButton = driver.findElement(By.xpath("//input[@class='button button-primary']"));

		wait.until(ExpectedConditions.visibilityOf(userNameBar_loginPage));
		userNameBar_loginPage.clear();
		userNameBar_loginPage.sendKeys(id);

		pwdNameBar_loginPage.clear();
		pwdNameBar_loginPage.sendKeys(pwd);

		wait.until(ExpectedConditions.elementToBeClickable(loginButton_loginPage));
		loginButton_loginPage.click();
	}

	public boolean LoginErrorCheck() throws InterruptedException {
		Thread.sleep(1000);

		if (driver.findElement(By.xpath("//form[@action='/signin/']//div//div[@class='okta-form-infobox-error infobox infobox-error']")).isDisplayed()) {
			System.out.println("Error is displayed for login creds");
			return true;
		} else {
			System.out.println("Error not displayed for login creds");
			return false;
		}
	}

	
	
	
}

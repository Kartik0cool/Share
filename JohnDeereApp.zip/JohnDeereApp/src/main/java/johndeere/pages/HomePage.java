package johndeere.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import johndeere.base.TestBase;

public class HomePage extends TestBase {

	//initializing page object
	public HomePage() throws InterruptedException {
		PageFactory.initElements(driver, this);
	}
	
	

}
